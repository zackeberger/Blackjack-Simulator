import java.util.*;

public class Blackjack {

	public static void main(String[] args) 
	{
		Scanner s = null;
		s = new Scanner(System.in);

		System.out.println("Welcome to Zack's Casino, now with these games: \n - Blackjack");
		System.out.println("\nType a game name to play it OR \"quit\" to exit.");

		// Entry into the casino.
		String entryCommand = s.nextLine();

		while (!entryCommand.equalsIgnoreCase("quit")) 
		{

			// Entry into the Blackjack game.
			if (entryCommand.equalsIgnoreCase("Blackjack")) 
			{

				System.out.println("\nWelcome to Blackjack! The Rules:");
				System.out.println(
						"\t- Type \"see hand\" to see your cards. \n\t- Type \"hand value\" for a numeric value of your hand.");
				System.out.println(
						"\t- Aces are initially valued at 1. You can toggle the value of an ace between 1 and 11 with the command \"ace change\".");
				System.out.println("\t- You can either \"hit\" to get another card, or \"stay\" to end your turn.");
				System.out.println("\nType \"new game\" or \"quit\".");

				String command = s.nextLine();

				while (!command.equalsIgnoreCase("quit")) 
				{

					if (command.equalsIgnoreCase("new game")) 
					{
						blackjack();
						System.out.println("\nPlay again? Type \"new game\" or \"quit\"");
					} 
					else 
					{
						System.out.println("Please enter a valid input");
					}

					command = s.nextLine();
				}

				if (command.equalsIgnoreCase("quit")) 
				{
					System.out.println("Thank you for playing Blackjack!");

					System.out.println("\nWelcome back to Zack's Casino, still with these games: \n - Blackjack");
					System.out.println("\nType a game name to play it OR \"quit\" to exit.");
				}

			} 
			else 
			{
				System.out.println("Please enter a valid input");
			}

			entryCommand = s.nextLine();

		}

		if (entryCommand.equalsIgnoreCase("quit")) 
		{
			System.out.println("Thank you for visiting Zack's Casino! Come back soon!");
		}

	}

	// The Blackjack game.
	public static void blackjack() 
	{
		Deck deck = new Deck();
		deck.shuffle();

		Scanner s = new Scanner(System.in);

		Dealer dealer = new Dealer();
		Hand user = new Hand();

		// Dealer receives two cards.
		dealer.addCard(deck.getCard());
		dealer.addCard(deck.getCard());

		// Sees if dealer has blackjack.
		boolean dealerBlackjack = dealer.blackjack();

		// If dealer does not have blackjack, dealer hits if hand value is below 17.
		// Otherwise, stays.
		// If dealer has blackjack, hand value is set to 21 by upgrading the ace's value
		// to 11 from 1.
		if (dealerBlackjack == false) 
		{
			dealer.hitOrStay();

			while (dealer.playStatus()) 
			{
				dealer.addCard(deck.getCard());
				dealer.hitOrStay();
			}
		} 
		else 
		{
			if (dealer.getHand().get(0) instanceof Ace) 
			{
				dealer.getHand().get(0).changeSoft();
			} 
			else if (dealer.getHand().get(1) instanceof Ace) 
			{
				dealer.getHand().get(1).changeSoft();
			}
		}

		// Player receives two cards.
		user.addCard(deck.getCard());
		user.addCard(deck.getCard());

		System.out.println("\nThe dealer has dealt you two cards: " + user.seeHand());

		String play = s.nextLine();

		// Player options for what to do.
		while (!play.equalsIgnoreCase("stay")) 
		{

			if (play.equalsIgnoreCase("see hand")) 
			{
				System.out.println(user.seeHand());
			} 
			else if (play.equalsIgnoreCase("hand value")) 
			{
				System.out.println(user.getHandValue());
			} 
			else if (play.equalsIgnoreCase("hit")) 
			{

				Card subject = deck.getCard();

				System.out.println(subject.getName() + " added to hand");
				user.addCard(subject);

			} 
			else if (play.equalsIgnoreCase("ace change")) 
			{
				if (user.hasAces()) 
				{

					Scanner scan = new Scanner(System.in);

					for (int i = 0; i < user.getHand().size(); i++) 
					{
						if (user.getHand().get(i) instanceof Ace) 
						{
							System.out.println(user.getHand().get(i).getName() + " valued at: "
									+ user.getHand().get(i).getValue());
							
							System.out.println("Change value? \"confirm\" or type \"no\"");
							
							String answer = scan.nextLine();

							if (answer.equalsIgnoreCase("confirm")) 
							{
								user.getHand().get(i).changeSoft();
							}

							System.out.println(user.getHand().get(i).getName() + " now valued at: "
									+ user.getHand().get(i).getValue());
						}
					}
				} 
				else 
				{
					System.out.println("You have no aces");
				}
			} 
			else 
			{
				System.out.println("Please enter a valid input");
			}

			if (user.getHandValue() > 21) 
			{
				System.out.println("Hand value: " + user.getHandValue() + ". You busted -- you lose!");
				
				break;
			}

			play = s.nextLine();
		}

		// End of game determination: victory, loss, tie.
		if (user.getHandValue() > 21) 
		{
			user.changeBustStatus();
		} 
		else 
		{

			System.out.println("Dealer's Hand: " + dealer.seeHand() + ", valued at " + dealer.getHandValue());
			System.out.println("Your hand: " + user.seeHand() + ", valued at " + user.getHandValue() + "\n");

			if (dealer.getHandValue() == user.getHandValue()) 
			{
				System.out.println("It's a tie!");
			} 
			else if (dealer.getBust() && user.getBust()) 
			{
				System.out.println("You and the dealer busted -- It's a tie!");
			} 
			else if (dealer.getBust() && !user.getBust()) 
			{
				System.out.println("Dealer busted -- you win!");
			} 
			else if (!dealer.getBust() && user.getBust()) 
			{
				System.out.println("You busted -- you lose!");
			} 
			else if (dealer.getHandValue() > user.getHandValue()) 
			{
				System.out.println("Dealer wins!");
			} 
			else if (dealer.getHandValue() < user.getHandValue()) 
			{
				System.out.println("You beat the house! Congratulations!");
			}
		}
	}
}
